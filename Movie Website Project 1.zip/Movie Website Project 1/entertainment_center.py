import media
import fresh_tomatoes

#using the Movie() class imported from media to initialize the instances of movies with instance variables
toy_story = media.Movie("Toy Story", "A story of a boy and his toys tha come to life.", "http://www.dvdsreleasedates.com/posters/800/T/Toy-Story-movie-poster.jpg","https://youtu.be/KYz2wyBy3kc")
avatar = media.Movie("Avatar", "A marine on an alien planet.", "http://www.coolshite.net/wp-content/uploads/2009/12/Avatar-Poster.jpeg","https://youtu.be/5PSNL1qE6VY")
perks_of_being_awf = media.Movie("Perks Of Being A Wallflower","A funny and touching coming of age story.", "https://www.amctheatres.com/Media/Default/BlogPost/movie-news/hr_The_Perks_of_Being_a_Wallflower_.jpg","https://www.youtube.com/watch?v=KGFqqp1d3BM")
school_of_rock = media.Movie("School Of Rock","Using rock music to learn.","https://images.duckduckgo.com/iu/?u=http%3A%2F%2Fimages.moviepostershop.com%2Fthe-school-of-rock-movie-poster-2003-1020191888.jpg&f=1","https://www.youtube.com/watch?v=eAry-ZV_gfs")
ratatouille = media.Movie("Ratatouille","A rat is a chef in Paris.","https://images.duckduckgo.com/iu/?u=http%3A%2F%2F1.bp.blogspot.com%2F-vqoqCOPHmmk%2FT-snhE9P_fI%2FAAAAAAAAH2k%2Fsopqei9a4e0%2Fs1600%2FRatatouille%2B(2007)%2B3.jpg&f=1","https://www.youtube.com/watch?v=eh62Ri60lXI")
midnight_in_paris = media.Movie("Midnight in Paris","Going back in time to meet authors.","https://images.duckduckgo.com/iu/?u=http%3A%2F%2Fecx.images-amazon.com%2Fimages%2FI%2F61lOzxZV5XL.jpg&f=1","https://www.youtube.com/watch?v=-NoGpkSTK8k")
the_hunger_games = media.Movie("The Hunger Games","A really real reality show.","https://images.duckduckgo.com/iu/?u=http%3A%2F%2Fecx.images-amazon.com%2Fimages%2FI%2F51lIFU8bDfL.jpg&f=1","https://www.youtube.com/watch?v=mfmrPu43DF8")

#creating an array of the movie instances
movies = [toy_story, avatar, perks_of_being_awf, school_of_rock, ratatouille, midnight_in_paris, the_hunger_games]
print(media.Movie.__doc__)

#passing the array of movie instances to the open_movies_page function imported from fresh_tomatoes.py
fresh_tomatoes.open_movies_page(movies)

